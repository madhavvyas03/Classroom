package assign_2_ap_2020310;

public interface com {
	void viewcomment();
	void addcomment(String s);
}
