package assign_2_ap_2020310;

public interface change {
		void printinst();
		public String enterid();
		void viewlecturemat();
		void viewassessments();	
}
