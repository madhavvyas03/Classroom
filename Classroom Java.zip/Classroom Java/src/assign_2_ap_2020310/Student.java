package assign_2_ap_2020310;
import java.util.* ;
import java.util.Map.Entry;
public class Student implements change{
	static int a ;
	static Map<Integer, ArrayList<String>> submissions = new HashMap<Integer,ArrayList<String>>() ;
	static Map<Integer, Map<String, Integer>> assessments = new HashMap<Integer, Map<String, Integer>>();
	static Map<Integer, Map<String, Integer>> assessments1 = new HashMap<Integer, Map<String, Integer>>();
	static Map<Integer, Map<String, String>> opmapping = new HashMap<Integer, Map<String, String>>();
	@Override
	public void printinst() {
		System.out.println("1. View lecture materials\r\n"
				+ "2. View assessments\r\n"
				+ "3. Submit assessment\r\n"
				+ "4. View grades\r\n"
				+ "5. View comments\r\n"
				+ "6. Add comments\r\n"
				+ "7. Logout");
	}

	@Override
	public String enterid() {
		System.out.println("Students:\r\n"
				+ "0 - S0\r\n"
				+ "1 - S1\r\n"
				+ "2 - S2");
		Scanner sc = new Scanner(System.in);
		System.out.println("Choose id:");
		a = sc.nextInt();
		if (a==0) {
			System.out.println("Welcome I1");
			
			return "S0" ;
		}
		else if(a==1) {
			System.out.println("Welcome I1");
			
			return "S1";
		}
		else if(a==2) {
			System.out.println("Welcome I1");
			
			return "S2";
		}
		
		return "wrong";
	}

	@Override
	public void viewlecturemat() {
		// TODO Auto-generated method stub
		Instructor i = new Instructor();
		i.viewlecturemat();
		
	}

	@Override
	public void viewassessments() {
		// TODO Auto-generated method stub
		int count;
		count = 0 ;
		System.out.println("");
		if (g=="S0") {
			for (String i : Student.assessments.get(0).keySet()) {
				if (Student.submissions.get(0).contains(i)==false) {
					if (Instructor.assignments.get(i)!=null) {
						System.out.println("ID:"+count+" Assignment: "+i+" Max Marks: "+Instructor.assignments.get(i));
						count++;
					}
					else {
						System.out.println("ID:"+count+" Question : "+i);
						count++;
					}
				}
			}
		}
		else if (g=="S1") {
			for (String i : Student.assessments.get(1).keySet()) {
				if (Student.submissions.get(1).contains(i)==false) {
					if (Instructor.assignments.get(i)!=null) {
						System.out.println("ID:"+count+" Assignment: "+i+" Max Marks: "+Instructor.assignments.get(i));
						count++;
					}
					else {
						System.out.println("ID:"+count+" Question : "+i);
						count++;
					}
				}
			}
		}
		else if (g=="S2") {
			for (String i : Student.assessments.get(2).keySet()) {
				if (Student.submissions.get(2).contains(i)==false) {
					if (Instructor.assignments.get(i)!=null) {
						System.out.println("ID:"+count+" Assignment: "+i+" Max Marks: "+Instructor.assignments.get(i));
						count++;
					}
					else {
						System.out.println("ID:"+count+" Question : "+i);
						count++;
					}
				}
			}
		}
		
		
	}
	static String g;
	public static void main() {
		Student s = new Student();
		Comments c = new Comments();
		g = s.enterid();
		Scanner sc = new Scanner(System.in);
		default_ass();
		if (g=="wrong") {
			System.out.println("Enter valid Id ");
			s.enterid();
		}
		for (int x = 0 ; x<Integer.MAX_VALUE ; x++){
			s.printinst();
			int f = sc.nextInt();
			if (f==1) {
				s.viewlecturemat();
			}
			else if (f==2) {
				Instructor i = new Instructor();
				i.viewassessments();
			}
			else if (f==3) {
				System.out.println("Submission"+s.submissions);
				if(g=="S0") {
					if (s.assessments.get(0).isEmpty()) {
						System.out.println("No pending submissions");
						break;
					}
				}
				if(g=="S1") {
					if (s.assessments.get(1).isEmpty()) {
						System.out.println("No pending submissions");
						break;
					}
				}
				if(g=="S2") {
					if (s.assessments.get(2).isEmpty()) {
						System.out.println("No pending submissions");
						break;
					}
				}
				
				if (g=="S0") {
					System.out.println("Pending Assignments");
					int count=0;
					if (assessments.containsKey(0)) {
						for (String uwu : assessments1.get(0).keySet()) {
							if (s.submissions.containsKey(0)) {
								if (s.submissions.get(0).contains(uwu)==false) {
									if (assessments.get(0).get(uwu)==null) {
										System.out.println("ID: "+ count + "Question :"+uwu);
					                 
									}
									else {
										System.out.println("ID: "+count+" Assignment: "+uwu);
									}
								}
								count++;
							}
							else {
								if (assessments.get(0).get(uwu)==null) {
									System.out.println("ID: "+ count + "Question :"+uwu);
								}
								else {
									System.out.println("ID: "+count+" Assignment: "+uwu);

								}
								count++;
							}
						}
					}
				}
				else if (g=="S1") {
					System.out.println("Pending Assignments");
					int count=0;
					if (assessments.containsKey(1)) {
						for (String uwu : assessments1.get(1).keySet()) {
							if (s.submissions.containsKey(1)) {
								if (s.submissions.get(1).contains(uwu)==false) {
									if (assessments.get(1).get(uwu)==null) {
										System.out.println("ID: "+ count + "Question :"+uwu);
									}
									else {
										System.out.println("ID: "+count+" Assignment: "+uwu);
									}
								}
							}
							else {
								if (assessments.get(1).get(uwu)==null) {
									System.out.println("ID: "+ count + "Question :"+uwu);
								}
								else {
									System.out.println("ID: "+count+" Assignment: "+uwu);
								}
						
							}
							count++;
						}
					}
				}
				else if (g=="S2") {
					System.out.println("Pending Assignments");
					int count=0;
					if (assessments.containsKey(2)) {
						for (String uwu : assessments1.get(2).keySet()) {
							if (s.submissions.containsKey(2)) {
								if (s.submissions.get(2).contains(uwu)==false) {
									if (assessments.get(2).get(uwu)==null) {
										System.out.println("ID: "+ count + "Question :"+uwu);
									}
									else {
										System.out.println("ID: "+count+" Assignment: "+uwu);
									}
								}
							}
							else {
								if (assessments.get(2).get(uwu)==null) {
									System.out.println("ID: "+ count + "Question :"+uwu);
								}
								else {
									System.out.println("ID: "+count+" Assignment: "+uwu);
								}
							}
							count++;
						}
					}
				}
				pendingassignments(g);
			}
			else if (f==4) {
				if (g=="S0") {
					System.out.println("Graded Assignment");
					for ( String kl :Student.opmapping.get(0).keySet() ) {
						if (Instructor.grade_0.containsKey(kl)) {
							System.out.println("Submission : "+Student.opmapping.get(0).get(kl)+"\nMarks Obtained : "+Instructor.grade_0.get(kl)+"\nGraded By :  "+Instructor.grade_by0.get(kl));
						}
					}
					System.out.println("UnGraded ASssignment");
					for ( String kl :Student.opmapping.get(0).keySet() ) {
						if (Instructor.grade_0.containsKey(kl)==false) {
							System.out.println("Submission : "+Student.opmapping.get(0).get(kl));
						}
					}
					
				}
				else if (g=="S1") {
					System.out.println("Graded Assignment");
					for ( String kl :Student.opmapping.get(1).keySet() ) {
						if (Instructor.grade_1.containsKey(kl)) {
							System.out.println("Submission : "+Student.opmapping.get(1).get(kl)+"\nMarks Obtained : "+Instructor.grade_1.get(kl)+"\nGraded By :  "+Instructor.grade_by1.get(kl));
						}
					}
					System.out.println("UnGraded ASssignment");
					for ( String kl :Student.opmapping.get(1).keySet() ) {
						if (Instructor.grade_1.containsKey(kl)==false) {
							System.out.println("Submission : "+Student.opmapping.get(1).get(kl));
						}
					}
					
				}
				else if (g=="S2") {
					System.out.println("Graded Assignment");
					for ( String kl :Student.opmapping.get(0).keySet() ) {
						if (Instructor.grade_2.containsKey(kl)) {
							System.out.println("Submission : "+Student.opmapping.get(2).get(kl)+"\nMarks Obtained : "+Instructor.grade_2.get(kl)+"\nGraded By :  "+Instructor.grade_by2.get(kl));
						}
					}
					System.out.println("UnGraded ASssignment");
					for ( String kl :Student.opmapping.get(0).keySet() ) {
						if (Instructor.grade_2.containsKey(kl)==false) {
							System.out.println("Submission : "+Student.opmapping.get(2).get(kl));
						}
					}
					
				}
			}
			else if (f==5) {
				c.viewcomment();
			}
			else if (f==6) {
				c.addcomment(g);
			}
			else if (f==7) {
				
				return ; 
			}
		
		}
		
	}
	private static void pendingassignments(String g) {
		Scanner sc = new Scanner(System.in);
		
		if (g=="S0") {
			System.out.print("Enter ID of Assessment :");
			int x = Integer.parseInt(sc.nextLine());
			Student s = new Student();
			int count=0;
			Set<String> keySet = assessments.get(0).keySet();
	        ArrayList<String> tarlist = new ArrayList<String>(keySet);
			String target = tarlist.get(x);
			ArrayList<String> up = new ArrayList<String>();
			if (s.submissions.containsKey(0)){
				up = s.submissions.get(0);
			}
			if (s.assessments.get(0).get(target)!=null) {
				System.out.print("Enter filename of assignment: ");
				String input = sc.nextLine();
				if (input.contains(".zip")) {
					Map<String,String> temp = new HashMap<String,String>() ;
					if (s.opmapping.containsKey(0)) {
						temp=s.opmapping.get(0);
						temp.put(target, input);
						
					}
					else {
						temp.put(target, input);
					}
					Student.opmapping.put(0, temp);
					up.add(target);
					Student.submissions.put(0,up);
					Student.assessments.get(0).remove(target);
					return;
					
				}
				else {
					System.out.println("Wrong type of file ");
					
					return;
				}
				
			}
			else {
				System.out.print(target);
				String as = sc.nextLine();
				Map<String,String> temp = new HashMap<String,String>() ;
				if (s.opmapping.containsKey(0)) {
					temp=s.opmapping.get(0);
					temp.put(target, as);
					s.opmapping.put(0, temp);
				}
				else {
					temp.put(target, as);
					s.opmapping.put(0, temp);
				}
				up.add(target);
				s.submissions.put(0,up);
				Student.assessments.get(0).remove(target);
				return ; 
			}
			
		}
		else if (g=="S1") {
			System.out.print("Enter ID of Assessment :");
			int x = Integer.parseInt(sc.nextLine());
			Student s = new Student();
			int count=0;
			Set<String> keySet = assessments.get(1).keySet();
	        ArrayList<String> tarlist = new ArrayList<String>(keySet);
			String target = tarlist.get(x);
			ArrayList<String> up = new ArrayList<String>();
			if (s.submissions.containsKey(1)){
				up = s.submissions.get(1);
			}
			if (s.assessments.get(1).get(target)!=null) {
				System.out.print("Enter filename of assignment: ");
				String input = sc.nextLine();
				if (input.contains(".zip")) {
					Map<String,String> temp = new HashMap<String,String>() ;
					if (s.opmapping.containsKey(1)) {
						temp=s.opmapping.get(1);
						temp.put(target, input);
						
					}
					else {
						temp.put(target, input);
					}
					Student.opmapping.put(1, temp);
					up.add(target);
					Student.submissions.put(1,up);
					Student.assessments.get(1).remove(target);
					return;
					
				}
				else {
					System.out.println("Wrong type of file ");
					
					return;
				}
				
			}
			else {
				System.out.print(target);
				String as = sc.nextLine();
				Map<String,String> temp = new HashMap<String,String>() ;
				if (s.opmapping.containsKey(1)) {
					temp=s.opmapping.get(1);
					temp.put(target, as);
					s.opmapping.put(1, temp);
				}
				else {
					temp.put(target, as);
					s.opmapping.put(1, temp);
				}
				up.add(target);
				s.submissions.put(1,up);
				Student.assessments.get(1).remove(target);
				return ; 
			}
			
		}
		else if (g=="S2") {
			System.out.print("Enter ID of Assessment :");
			int x = Integer.parseInt(sc.nextLine());
			Student s = new Student();
			int count=0;
			Set<String> keySet = assessments.get(2).keySet();
	        ArrayList<String> tarlist = new ArrayList<String>(keySet);
			String target = tarlist.get(x);
			ArrayList<String> up = new ArrayList<String>();
			if (s.submissions.containsKey(2)){
				up = s.submissions.get(2);
			}
			if (s.assessments.get(2).get(target)!=null) {
				System.out.print("Enter filename of assignment: ");
				String input = sc.nextLine();
				if (input.contains(".zip")) {
					Map<String,String> temp = new HashMap<String,String>() ;
					if (s.opmapping.containsKey(2)) {
						temp=s.opmapping.get(2);
						temp.put(target, input);
						
					}
					else {
						temp.put(target, input);
					}
					Student.opmapping.put(2, temp);
					up.add(target);
					Student.submissions.put(2,up);
					Student.assessments.get(2).remove(target);
					return;
					
				}
				else {
					System.out.println("Wrong type of file ");
					
					return;
				}
				
			}
			else {
				System.out.print(target);
				String as = sc.nextLine();
				Map<String,String> temp = new HashMap<String,String>() ;
				if (s.opmapping.containsKey(2)) {
					temp=s.opmapping.get(2);
					temp.put(target, as);
					s.opmapping.put(2, temp);
				}
				else {
					temp.put(target, as);
					s.opmapping.put(2, temp);
				}
				up.add(target);
				s.submissions.put(2,up);
				Student.assessments.get(2).remove(target);
				return ; 
			}
			
		}
		
	}

	static void default_ass() {
		Student s = new Student();
		Map<String,Integer> temp = new HashMap<String,Integer>();
		Map<String,Integer> temp1 = new HashMap<String,Integer>();
		Map<String,Integer> temp2 = new HashMap<String,Integer>();
		temp = Instructor.assignments ;
		temp1 = Instructor.assignments ;
		temp2 = Instructor.assignments ;
		s.assessments.put(0, temp);
		s.assessments.put(1, temp1);
		s.assessments.put(2, temp2);
		s.assessments1.put(0, temp);
		s.assessments1.put(1, temp1);
		s.assessments1.put(2, temp2);
		
	}
	public static <K, V> Map<K, V> copyMap(Map<K, V> original)
    {
        return new HashMap<>(original);
    }
}
